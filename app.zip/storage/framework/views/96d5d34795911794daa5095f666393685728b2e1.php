

<?php $__env->startSection('content'); ?>

<?php
use App\Models\Tree;
use App\Models\TreeRoot;
?>

<div class="card shadow">
    <div class="card-body">
        <h3 class="card-title text-center"><?php echo e($name); ?></h3>
        <h6 class="card-subtitle mb-2 text-muted text-center">Nombre de nœuds: <?php echo e($count); ?></h6>
        <div class="card-text mt-5">

            <div class="form-group row">
                <div class="col-sm-10 col-md-6">
                    <div class="alert alert-danger" role="alert" id="error" style="display:none">
                    </div>
                    <div class="alert alert-success" role="alert" id="success" style="display:none">
                    </div>
                </div>
            </div>

            <div class="tree offset-1 col-6">
                <?php echo $data; ?>

            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Tree-test\resources\views/show_tree.blade.php ENDPATH**/ ?>